/*=========================================================================

  Program:   My ITK GUI - A Foundation for Pipeline Visualization in ITK
  Module:    $RCSfile: migApp.cxx,v $
  Language:  C++
  Date:      $Date: 2003/03/02 19:37:56 $
  Version:   $Revision: 1.1.1.1 $

  Copyright (c) 2003 Damion Shelton

  All rights reserved.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notices for more information.

=========================================================================*/

#include "migApp.h"

migApp
::migApp()
{
}


migApp
::~migApp()
{
}

void 
migApp
::Show(void)
{
  this->migAppGUI::Show();
}
