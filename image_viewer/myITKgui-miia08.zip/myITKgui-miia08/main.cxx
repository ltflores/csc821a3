/*=========================================================================

  Program:   My ITK GUI - A Foundation for Pipeline Visualization in ITK
  Module:    $RCSfile: main.cxx,v $
  Language:  C++
  Date:      $Date: 2004/02/15 21:21:23 $
  Version:   $Revision: 1.2 $

  Copyright (c) 2003 Damion Shelton

  All rights reserved.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notices for more information.

=========================================================================*/

#include "migApp.h"
#include <FL/Fl.H>

int main(int, char**)
{
  migApp theApp;
  theApp.Show();

  Fl::run();
  return 0;
}
