/*=========================================================================

  Program:   My ITK GUI - A Foundation for Pipeline Visualization in ITK
  Module:    $RCSfile: migAppBase.cxx,v $
  Language:  C++
  Date:      $Date: 2004/03/04 19:03:29 $
  Version:   $Revision: 1.7 $

  Copyright (c) 2003 Damion Shelton

  All rights reserved.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notices for more information.

=========================================================================*/

#include "migAppBase.h"

#include <FL/Fl.H>
#include <FL/Fl_File_Chooser.H>

#include <itkMetaImageIOFactory.h>

migAppBase
::migAppBase()
{
  // The file name of the image we're reading
  m_InputImageFilename = new char[256];

  // The first time update is called we need to do some extra stuff
  m_IsFirstUpdate = true;

  m_InputImage = 0;
  m_ProcessedImage = 0;
  m_BeforeWindow = 0;
  m_AfterWindow = 0;
}

migAppBase
::~migAppBase()
{
  if( m_InputImageFilename )
    delete[] m_InputImageFilename;
  
  if(m_BeforeWindow)
    delete m_BeforeWindow;
  
  if(m_AfterWindow)
    delete m_AfterWindow;
}

void
migAppBase
::ReadImage()
{
  cout << "In ReadImage()" << endl;

  // Can only read an image once
  if(m_InputImage != (void*)0)
	  return;
  
  // Show a dialog box to let the user pick a file
  char* chooserName = fl_file_chooser("Pick a .mha file to load", "*.mha", 0, 0);

  // Store the filename
  strcpy( m_InputImageFilename, chooserName );

  cout << "Opening file with name: " << m_InputImageFilename << endl;

  // Now we can read the file
  m_ImageReader = ImageFileReaderType::New();
  itk::MetaImageIOFactory::RegisterOneFactory();
  m_ImageReader->SetFileName( m_InputImageFilename );
  m_InputImage = m_ImageReader->GetOutput();
  m_InputImage->SetRequestedRegionToLargestPossibleRegion();
  m_ImageReader->Update();

  // Create and show the two image viewer windows
  m_BeforeWindow = new migWindow;
  m_BeforeWindow->renderWindow->label("myITKgui - 'Before' Image");
  m_BeforeWindow->Show();
  
  m_AfterWindow = new migWindow;
  m_AfterWindow->renderWindow->label("myITKgui - 'After' Image");
  m_AfterWindow->Show();

  m_BeforeWindow->CreateRenderer();
  m_AfterWindow->CreateRenderer(); 

  // Finally, create the ITK pipeline (but don't run it)
  this->CreateITKPipeline();
}

void
migAppBase
::CreateITKPipeline()
{
  // Set up our example filter
  m_ThresholdFilter = ThresholdType::New();
  m_ThresholdFilter->SetInput(m_InputImage);
  m_ThresholdFilter->SetOutsideValue( 0 );
  m_ThresholdFilter->SetInsideValue( 255 );
  m_ThresholdFilter->SetLowerThreshold( 25 );
  m_ThresholdFilter->SetUpperThreshold( 100 );
  
  // Get the final pipeline output... be sure to do this in your revisions!
  m_ProcessedImage = m_ThresholdFilter->GetOutput();
}

void
migAppBase
::UpdatePipelineCallback()
{
  // Update the pipeline
  m_ThresholdFilter->Update();

  if(m_IsFirstUpdate)
  {
    // Show the input image
    m_BeforeWindow->SetImage(m_InputImage);
    m_BeforeWindow->CreateImagePlanes();
  
    // Show the output image
    m_AfterWindow->SetImage(m_ProcessedImage);
    m_AfterWindow->CreateImagePlanes();

    // No longer the first update
    m_IsFirstUpdate = false;
  }
  
  m_BeforeWindow->Render();
  m_AfterWindow->Render();
}
