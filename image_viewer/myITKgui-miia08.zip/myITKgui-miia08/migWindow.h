/*=========================================================================



  Program:   My ITK GUI - A Foundation for Pipeline Visualization in ITK

  Module:    $RCSfile: migWindow.h,v $

  Language:  C++

  Date:      $Date: 2004/02/15 21:21:23 $

  Version:   $Revision: 1.2 $



  Copyright (c) 2003 Damion Shelton



  All rights reserved.



     This software is distributed WITHOUT ANY WARRANTY; without even

     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR

     PURPOSE.  See the above copyright notices for more information.



=========================================================================*/



#ifndef _migWindow_h

#define _migWindow_h



#include "migWindowGUI.h"



class migWindow : public migWindowGUI

{  

public:



  /** Display the window */

  void Show(void);



  /** Returns the interactor */

  vtkFlRenderWindowInteractor* GetFLInteractor() {return m_FlRenderWindowInteractor;}

  /** Creates the rendering stuff */
  void CreateRenderer();

  migWindow();

  ~migWindow();

};



#endif


