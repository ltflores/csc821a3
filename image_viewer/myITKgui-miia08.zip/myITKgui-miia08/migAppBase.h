/*=========================================================================

  Program:   My ITK GUI - A Foundation for Pipeline Visualization in ITK
  Module:    $RCSfile: migAppBase.h,v $
  Language:  C++
  Date:      $Date: 2004/02/15 21:21:23 $
  Version:   $Revision: 1.3 $

  Copyright (c) 2003 Damion Shelton

  All rights reserved.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notices for more information.

=========================================================================*/

#ifndef _migAppBase_h
#define _migAppBase_h

#include <stdio.h>

// Native ITK stuff
#include "itkSize.h"
#include "itkIndex.h"
#include "itkImage.h"
#include "itkBinaryThresholdImageFilter.h"

// File reader stuff
#include "itkImageFileReader.h"

// Image viewer window
#include "migWindow.h"

class migAppBase
{
public:

  /** Big keg-o'-typedefs */
  typedef itk::Image<unsigned char, 3> InputImageType;
  typedef itk::ImageFileReader<InputImageType> ImageFileReaderType;
  typedef itk::Image<double, 3> OutputImageType;
  typedef itk::VTKImageExport<InputImageType> itkVTKImageExportType;
  typedef itkVTKImageExportType::Pointer itkVTKImageExportPointerType;
  
  /** The type of filter the demo uses... changes this */
  typedef itk::BinaryThresholdImageFilter<InputImageType, InputImageType> ThresholdType;

  /** Read a META format image from disk */
  void ReadImage();
  
  /** Hook together an ITK pipeline */
  void CreateITKPipeline();
  
  /** Callback for making the ITK pipeline do something */
  void UpdatePipelineCallback();

  /** Constructor - not much to see */
  migAppBase();

  /** Destructor - not much to see */
  virtual ~migAppBase();

protected:

  /** Input image file name */
  char* m_InputImageFilename;

  /** The image reader */
  ImageFileReaderType::Pointer m_ImageReader;
  
  /** The image we loaded from the file */
  InputImageType::Pointer m_InputImage;
  
  /** The image that results from running the pipeline */
  InputImageType::Pointer m_ProcessedImage;

  /** Tracks whether this is the first time we've pressed "update" */
  bool m_IsFirstUpdate;
  
  /** The image viewer prior to the pipeline */
  migWindow* m_BeforeWindow;
  
  /** The image viewer after the pieline */
  migWindow* m_AfterWindow;
  
  /** The _EXAMPLE_ filter used here... you should change this */
  ThresholdType::Pointer m_ThresholdFilter;
};

#endif
