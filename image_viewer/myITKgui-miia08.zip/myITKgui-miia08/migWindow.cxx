/*=========================================================================

  Program:   My ITK GUI - A Foundation for Pipeline Visualization in ITK
  Module:    $RCSfile: migWindow.cxx,v $
  Language:  C++
  Date:      $Date: 2004/02/15 21:21:23 $
  Version:   $Revision: 1.2 $

  Copyright (c) 2003 Damion Shelton

  All rights reserved.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notices for more information.

=========================================================================*/

#include "migWindow.h"
#include "vtkActor.h"
#include "vtkAxes.h"
#include "vtkPolyDataMapper.h"
#include "vtkTubeFilter.h"

migWindow
::migWindow()
{
}


migWindow
::~migWindow()
{
}

void 
migWindow
::Show(void)
{
  this->migWindowGUI::Show();
}

void
migWindow
::CreateRenderer()
{
  cout << "begin CreateRenderer" << endl;

  // Create a new renderer and add it to the render window
  m_Renderer = vtkRenderer::New();
  m_RenderWindow = vtkRenderWindow::New();
  m_RenderWindow->AddRenderer( m_Renderer );

  // Set the render window of the FLTK window
  m_FlRenderWindowInteractor->SetRenderWindow(m_RenderWindow);
  m_FlRenderWindowInteractor->Initialize();

  // The background is black
  m_Renderer->SetBackground( 0.0, 0.0, 0.0 );

  // Make some axes
  vtkAxes *axes = vtkAxes::New();
    axes->SetOrigin(0, 0, 0);
    axes->SetScaleFactor(10.0);
  vtkTubeFilter *axesTubes = vtkTubeFilter::New();
    axesTubes->SetInput(axes->GetOutput());
    axesTubes->SetRadius(axes->GetScaleFactor()/25.0);
    axesTubes->SetNumberOfSides(6);
  vtkPolyDataMapper *axesMapper = vtkPolyDataMapper::New();
    axesMapper->SetInput(axesTubes->GetOutput());
  vtkActor *axesActor = vtkActor::New();
    axesActor->SetMapper(axesMapper);

  m_Renderer->AddActor(axesActor);

  // Now that the actor is added we can safely call delete
  axes->Delete();
  axesTubes->Delete();
  axesMapper->Delete();
  axesActor->Delete();

  // Render everything
  m_Renderer->ResetCamera();

  cout << "end CreateRenderer" << endl;
}
